"""
    A Quick experiment in wrapping the Iris Native interface in a more Pythonic style.
    See: iris_wrapped_test() for example usage.
"""
from collections import deque
import intersystems_iris


class IrisSlicer(object):
    """
    TODO: And Warning. IrisSlicer is just an experiment that doesn't work yet. Do not use.
    IrisSlicer represents a single Iris Global just like IrisGlobal does, except that this IrisSlicer provides higher
    level semantic operations in a separate class, so that IrisGlobal doesn't become overly complex and slow because of
    the complexity of argument parsing in low level operations like [].
    IrisSlicer is constructed from an IrisGlobal.slicer() call.
    usage:  my_slicer = IrisGlobal(IrisConnection(), ""MyGlob").slicer()
            dict = my_slicer[start:end:step, start:end:step ...]
    """
    def __init__(self, iris_global):
        self.iris_global = iris_global

    def __getitem__(self, keys=None):
        """Support for "value = my_global[slice, slice, ...]" syntax."""
        if type(keys) is not tuple:     # Single value/slice becomes tuple(x, )
            keys = tuple(keys,)
        iris_global = self.iris_global

        def iter_sub(prefix, next_keys):
            this_slice = next_keys[0]
            if type(this_slice) is slice:
                for this_key, this_value in iris_global.iteritems(key=prefix, reverse=False, start_from=this_slice.start):
                    if this_slice.stop is not None:
                        this_full_key = prefix + (type(this_slice.stop)(this_key),)
                        data = iris_global.data(this_full_key)
                        if IrisGlobal.data_has_value(data):
                            if this_full_key[-1] >= this_slice.stop:
                                break
                            yield this_full_key, this_value
                    else:
                        this_full_key = prefix + (this_key,)
                        data = iris_global.data(this_full_key)
                        if IrisGlobal.data_has_value(data):
                            yield this_full_key, this_value
                    if IrisGlobal.data_has_child(data) and len(next_keys) > 1:
                        yield from iter_sub(this_full_key, next_keys[1:])
            else:
                # Assume this_slice is specific value instead if being an actual slice.
                this_key = (() if prefix is None else prefix) + (this_slice,)
                data = iris_global.data(this_key)
                if IrisGlobal.data_has_value(data):
                    yield this_key, iris_global[this_key]
                if IrisGlobal.data_has_child(data) and len(next_keys) > 1:
                    yield from iter_sub(this_key, next_keys[1:])

        return {key: value for key, value in iter_sub((), keys)}


class IrisConnectionException(Exception):
    """Represents a failure to connect to IRIS"""


class IrisTransaction(object):
    """
    Supports Syntax like:
                with con.transaction() as tran:
                    my_glob[1, 2, 3] = 42
                    break                # Breaks out and Auto-commits transaction.
                    tran.commit()        # Breaks out and commits transaction
                    tran.rollback_one()  # Breaks out and rollback_one's tran
                    tran.rollback_all()  # Breaks out and rollback_all's tran
    """
    class BreakingGood(Exception):
        pass    # breaking out of with, via commit.

    class BreakingBad(Exception):
        pass    # breaking out of with, via rollback_one.

    class BreakingReallyBad(Exception):
        pass    # breaking out of with, via rollback_all.

    def __init__(self, iris, trans_depth):
        self.iris = iris
        self._iris = iris.get_iris()
        self.trans_depth = trans_depth

    def __enter__(self):
        """Implements "with con.start_transaction as trans:" syntax."""
        self._iris.tStart()
        return self

    def __exit__(self, ex_type, ex_value, ex_traceback):
        """Decide how we're wrapping up the transaction"""
        self.iris.pop_transaction()
        if ex_type in (None, IrisTransaction.BreakingGood):
            self._iris.tCommit()
            return True     # commit() called. Commit the transaction and suppress this exception.
        if ex_type is IrisTransaction.BreakingBad:
            self._iris.tRollbackOne()
            return True     # rollback_one() called. Rollback the transaction and suppress this exception.
        if ex_type is not IrisTransaction.BreakingReallyBad:
            self._iris.tRollbackOne()
            return False    # Unexpected exception: Rollback one level and throw exception to the keeper.

        # rollback_all() called. Full rollback already done.
        if self.trans_depth == 0:
            return True     # Suppress  exception at base transaction level.
        return False        # Propagate exception at higher transaction levels.

    def commit(self):
        raise self.BreakingGood

    def rollback_one(self):
        raise self.BreakingBad

    def rollback_all(self):
        self._iris.tRollback()
        raise self.BreakingReallyBad


class IrisGlobal(object):
    """
    IrisGlobal represents a single Iris Global of name 'global_name', accessed via a connection 'iris'
        usage:  my_glob = IrisGlobal(iris, "MyGlob")        # Prepare to use an Iris global named ^MyGlob. Equivalent to iris.MyGlob
                my_glob.name()                              # -> "^MyGlob"
                my_glob[None] = 42                          # set ^MyGlob = 42
                x = my_glob[None]                           # set x = ^MyGlob           except x is in Python
                my_glob[1,2,3] = 42                         # set ^MyGlob(1,2,3) = 42
                tup = (1,2,3)
                my_glob[*tup] = 42                          # set ^MyGlob(1,2,3) = 42
                x = my_glob[1,2,3]                          # set x = ^MyGlob(1,2,3)    except x is in Python
                x = my_glob(1,2,3)                          # set x = ^MyGlob(1,2,3)    except x is in Python
                del my_glob[1,2,3]                          # kill ^MyGlob(1,2,3)       Python style
                my_glob.kill((1,2,3))                       # kill ^MyGlob(1,2,3)       Closer to Object Script style
                for k,v in my_glob.iteritems()              # $Order iterate key,value pairs at root of ^MyGlob
                for k,v in my_glob.iteritems(reverse=True)  # $Order iterate in reverse
                for k,v in my_glob.iteritems(key=(1,2),     # $Order iterate in subscripts below (1,2),
                                             start_from=1)  #                   starting from (1,2,1).
                for k   in my_glob.iterkeys((1,2))          # $Order iterate key             below subroot of [1,2]
                for v   in my_glob.itervalues((1,))         # $Order iterate value           at root of ^MyGlob
                my_glob.increment((1,2), 1)                 # $Increment(^MyGlob(1,2))
                my_glob.lock((1,2,3))                       # lock ^MyGlob(1,2,3)
                my_glob.unlock((1,2,3))                     # unlock ^MyGlob(1,2,3)
                my_glob.has_child((1,2,3))                  # $Data(^MyGlob(1,2,3)) = 10 or 11
                my_glob.has_value((1,2,3))                  # $Data(^MyGlob(1,2,3)) = 1  or 11
    """
    def __init__(self, iris, global_name):
        self.global_name = "^" + global_name
        if not iris.is_open():
            raise Exception("IRIS Connection not open")
        self._iris = iris.get_iris()

    def name(self):
        """The string name of this global."""
        return self.global_name

    def slicer(self):
        """Returns an IrisSlicer object based on this IrisGlobal"""
        return IrisSlicer(self)

    def _key_params(self, key):
        """Standardised evaluation of subscripts, passed as None, singleValue or (tuple)"""
        return (self.global_name, *key) if type(key) is tuple else\
               (self.global_name,) if key is None else\
               (self.global_name, key)

    def _value_key_params(self, value, key):
        """Standardised evaluation of value, subscripts, passed as None, singleValue or (tuple)"""
        return (value, self.global_name, *key) if type(key) is tuple else\
               (value, self.global_name,) if key is None else\
               (value, self.global_name, key)

    def has_child(self, key=None):
        """Does global[subscript] have subordinate subscripts."""
        return self._iris.isDefined(*self._key_params(key)) in (10, 11)

    def has_value(self, key=None):
        """Does global[subscript] have a value"""
        return self._iris.isDefined(*self._key_params(key)) in (1, 11)

    def data(self, key=None):
        """Gets the $Data(global) value"""
        return self._iris.isDefined(*self._key_params(key))

    @staticmethod
    def data_has_child(data):
        """Evaluates the $Data(global) value to tell if there are any child subscripts in the global."""
        return data in (10, 11)

    @staticmethod
    def data_has_value(data):
        """Evaluates the $Data(global) value to tell if this global subscript has a value."""
        return data in (1, 11)

    def __getitem__(self, key=None):
        """Support for "value = my_global[subscripts]" syntax."""
        return self._iris.get(*self._key_params(key))

    def __setitem__(self, key=None, value=None):
        """Support for "my_global[subscripts] = value" syntax."""
        try:
            self._iris.set(*self._value_key_params(value, key))
        except Exception as e:
            print(repr(e))

    def __delitem__(self, key=None):
        """Support for "del my_global[subscripts]" syntax."""
        return self._iris.kill(*self._key_params(key))

    def kill(self, key=None):
        """Kill my_global[subscripts]. Same effect as del my_global[subscripts]."""
        self.__delitem__(key)

    def increment(self, key=None, value=1):
        """my_global[subscripts] += value, as an atomic action."""
        return self._iris.increment(*self._value_key_params(value, key))

    def lock(self, key=None, lock_mode="", timeout=1):
        """ lock my_global[subscripts]
            lock_mode = "S"hared, "E"scalating or "SE",
            timeout is seconds
        """
        self._iris.lock(lock_mode, timeout, *self._key_params(key))

    def unlock(self, key=None, lock_mode=""):
        """ Unlock my_global[subscripts]
            lock_mode="I"mmed, "D"efer, "S"hare, "E"scalate or "SE"
        """
        self._iris.unlock(lock_mode, *self._key_params(key))

    def __call__(self, *args):
        """Support for "value = my_global(subscripts)" syntax."""
        return self.__getitem__(args)

    @staticmethod
    def iteritems_int_key(item_iter):
        for k, v in item_iter:
            yield int(k), v

    @staticmethod
    def iterkeys_int_key(key_iter):
        for k in key_iter:
            yield int(k)

    def iterkeys(self, key=None, reverse=False, start_from=None, int_key=False):
        """Iterate through keys at my_global(subscript), optionally after a value, or in reverse"""
        key_iter = self._iris.iterator(*self._key_params(key)).subscripts().startFrom(start_from)
        key_iter = key_iter.reversed() if reverse else key_iter
        return IrisGlobal.iterkeys_int_key(key_iter) if int_key else key_iter

    def itervalues(self, key=None, reverse=False, start_from=None):
        """Iterate through values at my_global(subscript), optionally after a value, or in reverse"""
        value_iter = self._iris.iterator(*self._key_params(key)).values().startFrom(start_from)
        return value_iter.reversed() if reverse else value_iter

    def iteritems(self, key=None, reverse=False, start_from=None, int_key=False):
        """Iterate through (key,value) at my_global(subscript), optionally after a value, or in reverse"""
        item_iter = self._iris.iterator(*self._key_params(key)).items().startFrom(start_from)
        item_iter = item_iter.reversed() if reverse else item_iter
        return IrisGlobal.iteritems_int_key(item_iter) if int_key else item_iter

    def iter_all(self, key=None):
        """Depth first iterator through all (key,value), at and below 'key'."""
        iter_stack = deque()
        key = key if type(key) is tuple else tuple() if key is None else tuple(key)
        if self.has_value(key):
            yield key, self(*key)
        iter_stack.append((key, self._iris.iterator(*self._key_params(key)).items()))
        while iter_stack:
            try:
                k, v = next(iter_stack[-1][1])
                try:
                    k = int(k)
                except ValueError:
                    pass
                key = tuple((*iter_stack[-1][0], k))
                yield key, v
                if self.has_child(key):
                    iter_stack.append((key, self._iris.iterator(*self._key_params(key)).items()))
            except StopIteration:
                iter_stack.pop()


class Iris(object):
    """
        Iris represents a connection to an Iris database
            usage:  try:
                        with Iris() as iris:
                            my_glob = IrisGlobal(iris, "MyGlob")    # or just iris.MyGlob
                            # Do various DB operations.
                            with iris.transaction() as tran:
                                my_glob[1,2,3] = 42

                                tran.rollback_one()     # Breaks out and rollback_one's tran
                                tran.rollback_all()     # Breaks out and rollback_all's tran
                                tran.commit()           # Breaks out and commits transaction

                                my_glob[1,2,4] = 43     # This won't happen

                    except IrisConnectionException as e:
                        print(repr(e))
    """
    def __init__(self,
                 ip="127.0.0.1", port=51791,
                 namespace="User", username="_SYSTEM", password="SYS",
                 timeout=10000, shared_memory=True, logfile=""):

        # Initially, no transaction is started.
        self.__trans = deque()

        # Make connection to InterSystems IRIS database
        self.__iris_connection = intersystems_iris.createConnection(hostname=ip, port=port, namespace=namespace,
                                                             username=username, password=password,
                                                             timeout=timeout, sharedmemory=shared_memory, logfile=logfile)

        if self.__iris_connection.isClosed():
            self.__iris_connection = None
            self.__iris = None
            raise IrisConnectionException("intersystems_iris.createConnection() - Failed to create open connection.")

        # Create an InterSystems IRIS native object
        try:
            self.__iris = intersystems_iris.createIRIS(self.__iris_connection)
        except Exception as e:
            self.__iris_connection.close()
            self.__iris_connection = None
            self.__iris = None
            raise IrisConnectionException(repr(e))

    def __getattr__(self, name) -> IrisGlobal:
        """Called when __getattribute__() already failed to find one."""
        if name[0] == "_":
            # print("__getattr__({}) returning object.__getattribute__(self, name)".format(name))
            return object.__getattribute__(self, name)
        # print("__getattr__({}) creating IrisGlobal".format(name))
        object.__setattr__(self, name, IrisGlobal(self, name))
        attr = object.__getattribute__(self, name)
        return attr

    def __setattr__(self, name, value):
        if name[0] == "_":
            object.__setattr__(self, name, value)
            return
        try:
            iris_global = object.__getattribute__(self, name)
        except AttributeError:
            iris_global = IrisGlobal(self, name)
            object.__setattr__(self, name, iris_global)
        iris_global.__setitem__(None, value)

    def __enter__(self):
        """__enter__() and __exit__() support "with Iris() as iris:" syntax."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """__enter__() and __exit__() support "with Iris() as iris:" syntax."""
        self.unlock_all()
        self.close()

    def get_iris(self):
        return self.__iris

    def is_open(self):
        """Is the connection to Iris open and nowhere to go."""
        return self.__iris is not None and self.__iris_connection is not None and not self.__iris_connection.isClosed()

    def using_shared_memory(self):
        """Is the connection to Iris using shared memory?"""
        return self.is_open() and self.__iris_connection.isUsingSharedMemory()

    def close(self):
        """We need better ways ti """
        self.__iris_connection.close()

    def unlock_all(self):
        self.__iris.releaseAllLocks()

    def transaction(self):
        trans = IrisTransaction(self, len(self.__trans))
        self.__trans.append(trans)
        return trans

    def pop_transaction(self):
        self.__trans.pop()
