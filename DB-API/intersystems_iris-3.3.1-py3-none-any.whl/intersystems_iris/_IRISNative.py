import intersystems_iris._PythonGateway
import intersystems_iris._IRIS
import intersystems_iris._IRISConnection

def createIRIS(connection):
    '''Return a new iris.IRIS object that uses the given connection.

iris.createIRIS(conn)

Throw an exception if the connection is closed.

Parameters
----------
conn : iris.IRISConnection
    connection object to use

Returns
-------
iris.IRIS
    A new IRIS object that uses the given connection.
'''
    return intersystems_iris.Iris(connection)

def createConnection(*args, **kwargs):
    '''This method has been deprecated. Please use connect() method instead.
'''
    return intersystems_iris._IRISConnection._IRISConnection(*args, **kwargs)
