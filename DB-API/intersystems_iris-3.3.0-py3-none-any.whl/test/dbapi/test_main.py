from decimal import Decimal
import datetime
import pytest
import intersystems_iris.dbapi._DBAPI as dbapi


config = {
    'hostname': 'localhost',
    'port': 1972,
    'namespace': 'USER',
    'username': '_SYSTEM',
    'password': 'SYS',
}

@pytest.mark.parametrize(
    "mode",
    ['network','embedded',]
)
class TestMain:
    @pytest.fixture
    def connection(self, mode):
        embedded = mode == 'embedded'
        with dbapi.connect(embedded=embedded, **config) as conn:
            # conn.iris.system.SQL.Purge()
            yield conn

    @pytest.fixture
    def cursor(self, connection):
        with connection.cursor() as cursor:
            yield cursor

    def test_simple(self, cursor: dbapi.Cursor):
        _ = cursor.direct_execute('select ?', [1])
        rows = cursor.fetchall()
        assert rows == [[1]]

    def test_literals(self, cursor: dbapi.Cursor):
        some_date = datetime.date(2012, 2, 3)
        some_datetime = datetime.datetime(2012, 2, 3, 10, 11, 12, 123)
        some_time = datetime.time(10, 11, 12, 123)
        some_decimal = Decimal('1.234')
        
        params = [
            2, 
            some_date, 
            some_datetime,
            some_time,
            some_decimal,
            None,
            '',
            True,
            False,
        ]
        _ = cursor.direct_execute("select 'text', 1, " + ', '.join(['?'] * len(params)), params)
        rows = cursor.fetchall()
        assert rows == [[
            'text',
            1, 
            2, 
            '2012-02-03',
            '2012-02-03 10:11:12.000123',
            '10:11:12.000123',
            Decimal('1.234'),
            None,
            '',
            1,
            0,
        ]]

    def test_with(self, cursor):
        cursor.direct_execute('with t1 as (select 1), t2 as (select 2) select * from t1 union all select * from t2')
        rows = cursor.fetchall()
        assert rows == [[1], [2]]

    def test_lateral(self, cursor):
        cursor.direct_execute('select * from (select ?) t1,  (select ?) t2', [1,2])
        rows = cursor.fetchall()
        assert rows == [[1, 2]]
