from ._DBList import _DBList
from ._ListItem import _ListItem


class _DBListDebug:
    def __str__(self) -> str:
        _list_item = _ListItem(self.buffer[14:self.offset])
        _items = []
        _locale = self._locale
        # print('_list_item', _list_item, _list_item.buffer)

        while (_list_item.next_offset < _list_item.list_buffer_end):
            # print('_item', _list_item.next_offset, _list_item.list_buffer_end, _list_item.buffer[_list_item.next_offset], _list_item.type)
            _DBList._get_list_element(_list_item)
            _item = _DBList._get(_list_item, _locale, True)
            # print(_item, type(_item))
            if isinstance(_item, bytes):
                _item = str(_item, _locale)
            _items.append('' if _item is None else '%r' % (_item, ))

        return '$lb(%s)' % (', '.join(_items))
