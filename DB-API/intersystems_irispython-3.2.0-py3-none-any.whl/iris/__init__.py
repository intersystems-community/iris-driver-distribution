'''
IRIS Native API for Python.

This module provides highly efficient and lightweight access to IRIS, including the Global Module and object oriented programming environment.
'''
import iris._BufferReader
import iris._BufferWriter
import iris._ConnectionInformation
import iris._ConnectionParameters
import iris._Constant
import iris._Device
import iris._DBList
import iris._GatewayContext
import iris._GatewayException
import iris._GatewayUtility
import iris._InStream
import iris._IRIS
import iris._IRISConnection
import iris._IRISGlobalNode
import iris._IRISGlobalNodeView
import iris._IRISIterator
import iris._IRISList
import iris._IRISObject
import iris._IRISOREF
import iris._IRISReference
import iris._LegacyIterator
import iris._ListItem
import iris._ListReader
import iris._ListWriter
import iris._LogFileStream
import iris._MessageHeader
import iris._OutStream
import iris._PrintStream
import iris._PythonGateway

from iris._IRISNative import connect
from iris._IRISNative import createConnection
from iris._IRISNative import createIRIS

class GatewayContext(iris._GatewayContext._GatewayContext): pass
class IRIS(iris._IRIS._IRIS): pass
class IRISConnection(iris._IRISConnection._IRISConnection): pass
class IRISGlobalNode(iris._IRISGlobalNode._IRISGlobalNode): pass
class IRISGlobalNodeView(iris._IRISGlobalNodeView._IRISGlobalNodeView): pass
class IRISIterator(iris._IRISIterator._IRISIterator): pass
class IRISList(iris._IRISList._IRISList): pass
class IRISObject(iris._IRISObject._IRISObject): pass
class IRISReference(iris._IRISReference._IRISReference): pass
class LegacyIterator(iris._LegacyIterator._LegacyIterator): pass

